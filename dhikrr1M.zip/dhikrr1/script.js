/* style.css */
body {
    font-family: 'Cairo', sans-serif; /* Modern font with clean lines */
    background: linear-gradient(135deg, #f0f5f0, #c0d6c0); /* Gradient background for a soothing feel */
    color: #004400; /* Dark green text for good contrast */
    text-align: center;
    padding: 50px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
    margin: 0;
}
#bismillah {
    font-size: 36px;
    margin-bottom: 20px;
    font-family: 'Amiri', serif; /* Use Arabic script font */
    color: #008000; /* Green color for Bismillah */
    text-shadow: 2px 2px 4px #aaa; /* Subtle shadow effect */
}
#counter {
    font-size: 72px;
    margin: 20px;
    font-weight: bold;
    color: #004400; /* Dark green for counter text */
    text-shadow: 1px 1px 2px #aaa; /* Subtle shadow effect */
}
button {
    background-color: #008000; /* Vibrant green for the button */
    color: white;
    border: none;
    padding: 15px 30px;
    font-size: 20px;
    cursor: pointer;
    border-radius: 10px; /* Rounded corners for the button */
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Soft shadow for a 3D effect */
    transition: background-color 0.3s, transform 0.3s; /* Smooth transition */
}
button:hover {
    background-color: #005500; /* Darker green on hover */
    transform: translateY(-2px); /* Lift button on hover */
}
button:active {
    transform: translateY(2px); /* Press button down on click */
}
